// Name: Ankita Pratap
// Roll No: 2301150

const express = require('express');
const router = express.Router();
const { body, validationResult } = require('express-validator');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const connection = require('../dbConfig.js');

router.get('/:id', async (req, res) => {
    const userId = req.params.id;

    connection.query('SELECT * FROM users WHERE id = ?', userId, (err, results) => {
        if (err) {
            console.error('Error getting user by ID: ', err);
            return res.status(500).send('Server Error');
        }

        if (results.length === 0) {
            return res.status(404).json({ message: 'User not found' });
        }

        const user = results[0];
        return res.json(user);
    });
});

router.put('/update-mobile/:id', async (req, res) => {
    const userId = req.params.id;
    const newMobile = req.body.mobile;

    connection.query('UPDATE users SET mobile = ? WHERE id = ?', [newMobile, userId], (err, result) => {
        if (err) {
            console.error('Error updating mobile: ', err);
            return res.status(500).send('Server Error');
        }

        if (result.affectedRows === 0) {
            return res.status(404).json({ message: 'User not found' });
        }

        return res.json({ message: 'Mobile updated successfully' });
    });
});

router.delete('/delete/:id', async (req, res) => {
    const userId = req.params.id;

    connection.query('UPDATE users SET isActive = 0 WHERE id = ?', userId, (err, result) => {
        if (err) {
            console.error('Error deleting user: ', err);
            return res.status(500).send('Server Error');
        }

        if (result.affectedRows === 0) {
            return res.status(404).json({ message: 'User not found' });
        }

        return res.json({ message: 'User deleted successfully' });
    });
});

module.exports = router;

