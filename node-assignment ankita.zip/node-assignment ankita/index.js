
// Name: Ankita Pratap
// Roll No: 2301150

// Node Js Assignment
const express = require('express');
const app = express();
const userRoutes = require('./routes/user');
const protectedRoutes = require('./routes/ProtectedRoutes');
const authMiddleware = require('./middleware/auth');

// Middleware for parsing JSON requests
app.use(express.json());

// Routes
app.use('/user', userRoutes);
app.use('/protected', authMiddleware, protectedRoutes);

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
