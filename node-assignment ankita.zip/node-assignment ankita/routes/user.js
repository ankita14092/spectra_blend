// Name: Ankita Pratap
// Roll No: 2301150

const express = require('express');
const router = express.Router();
const { body, validationResult } = require('express-validator');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const connection = require('../dbConfig.js');

router.post('/register', [
    body('name').notEmpty(),
    body('email').isEmail(),
    body('mobile').isMobilePhone(),
    body('password').isLength({ min: 6 }),
], async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
    }

    const hashedPassword = await bcrypt.hash(req.body.password, 10);

    const user = {
        name: req.body.name,
        email: req.body.email,
        mobile: req.body.mobile,
        password: hashedPassword,
        address: req.body.address,
        isActive: 1,
        created_at: new Date()
    };

    connection.query('INSERT INTO users SET ?', user, (err, result) => {
        if (err) {
            console.error('Error creating user: ', err);
            return res.status(500).send('Server Error');
        }
        return res.status(201).json({ message: 'User created successfully' });
    });
});

router.post('/login', async (req, res) => {
    const { email, password } = req.body;

    connection.query('SELECT * FROM users WHERE email = ?', email, async (err, results) => {
        if (err) {
            console.error('Error authenticating user: ', err);
            return res.status(500).send('Server Error');
        }

        if (results.length === 0) {
            return res.status(401).json({ message: 'Invalid email or password' });
        }

        const user = results[0];
        const isPasswordValid = await bcrypt.compare(password, user.password);

        if (!isPasswordValid) {
            return res.status(401).json({ message: 'Invalid email or password' });
        }

        const token = jwt.sign({ id: user.id, email: user.email }, 'your_secret_key', { expiresIn: '1h' });
        return res.json({ token });
    });
});



module.exports = router;
